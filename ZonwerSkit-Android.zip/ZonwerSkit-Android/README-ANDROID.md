# Zonwer Skit · proyecto Android (APK)

Este proyecto es una app de Android con el juego COMPLETO dentro (todo lo que tiene la versión web:
personajes, pase, tienda, taquilla, música, bailes, amigos, modo desarrollador...).
El juego está en `app/src/main/assets/index.html`. Necesita internet para cargar las librerías 3D.

## Opción A · Sin instalar nada (GitHub crea el APK por ti, gratis)
1. Crea una cuenta en https://github.com y pulsa **New repository** (ponle el nombre que quieras).
2. En el repositorio nuevo pulsa **uploading an existing file** y arrastra TODO el contenido de esta carpeta
   (descomprime el zip primero y arrastra los archivos y carpetas de dentro, no la carpeta contenedora).
3. Comprueba que existe el archivo `.github/workflows/build-apk.yml`. Si no aparece (las carpetas que empiezan por punto a veces no se suben):
   pulsa **Add file → Create new file**, escribe como nombre `.github/workflows/build-apk.yml` y pega el contenido de ese archivo del zip.
4. Ve a la pestaña **Actions**. Verás "Crear APK" ejecutándose (tarda 3-6 minutos). Si no arranca, pulsa **Run workflow**.
5. Cuando termine con ✅, entra en esa ejecución y abajo, en **Artifacts**, descarga **ZonwerSkit-APK**. Dentro está `app-debug.apk`.
6. Pásalo al móvil e instálalo (activa "instalar apps de orígenes desconocidos" si te lo pide).

## Opción B · Android Studio
1. Instala Android Studio (https://developer.android.com/studio), `File → Open` y elige esta carpeta.
2. `Build → Build Bundle(s) / APK(s) → Build APK(s)` y busca `app/build/outputs/apk/debug/app-debug.apk`.

## Google Play
Necesitas firmar la app: `Build → Generate Signed Bundle / APK` (guarda bien tu clave). Sube el `.aab`.

## Actualizar el juego
Cambia `app/src/main/assets/index.html` por la versión nueva, sube `versionCode` y `versionName` en `app/build.gradle` y vuelve a compilar (A o B).

## Notas
- Los amigos y la pantalla dividida funcionan dentro del APK (no dependen de Claude).
- Modo desarrollador: Ajustes → Desarrollador (o toca 7 veces la versión) y escribe tu código.
